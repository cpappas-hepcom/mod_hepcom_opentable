/**
 *  jQuery No Conflict Handler
 *  for mod_opentable
 *  @author   Chris Pappas <cpappas@hepcom.ca>
 *  @date     2011-03-28
 *  @version  0.1
 */
$.noConflict();
