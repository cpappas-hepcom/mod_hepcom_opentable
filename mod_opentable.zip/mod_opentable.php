<?php
/**
 * OpenTable Module Entry Point
 * 
 *  @author   Chris Pappas <cpappas@hepcom.ca>
 *  @version  1.0
 *  @date     2011-03-28
 */
 
// no direct access
defined( '_JEXEC' ) or die( 'Restricted access' );
 
require( JModuleHelper::getLayoutPath( 'mod_opentable' ) );


